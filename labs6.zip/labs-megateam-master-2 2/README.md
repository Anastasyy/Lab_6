# LAB5 Impl
### by `Vladislav Andreev` and `Anastasia Petrova`
### task id: `31191`

Javadoc is available [here](https://chuck-cheese.github.io/labs-megateam "Lab5 javadoc")